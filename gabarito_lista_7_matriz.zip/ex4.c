/*
4.
Somar uma matriz por linha, ou seja, obter o total de cada linha da matriz.
 No final gere uma tela de saída mostrando esses valores
 e o total geral de toda a matriz. Use uma ma-triz 4 x 5.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <stdlib.h>

void main(void) {
	setlocale(LC_ALL, "portuguese");
	int i, j;
	int m1[4][5]={0},soma[4]={0};
	for (i=0; i<4; i++) 
			for (j=0; j<5; j++){
	 
			printf ("Digite o valor da posicao %d, %d: ", i, j);
			scanf ("%d", &m1[i][j]);
	}
	for (i=0; i<4; i++) 
			for (j=0; j<5; j++)
	 {
			soma[i]=soma[i]+m1[i][j];
		}
	for (i=0; i<4; i++, printf ("\t Total linha = %d", soma[i-1]) )
		for (printf("\n"),j=0; j<5; j++)
					printf ("\t%d", m1[i][j]);
	for (j=0,i=0; i<4; i++) 
				j += soma[i];
	printf ("\n A soma de todos os elementos da matriz é  Total linha = %d", j) ;

}