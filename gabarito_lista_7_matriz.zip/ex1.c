/*
1.
Elabore um programa, utilizando laços encadeados, para armazenar doze valores numéricos inteiros numa matriz 3 x 4,
 ou seja, numa matriz com 3 linhas e 4 colunas. No final mostre os valores armazenados na matriz.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <stdlib.h>

void main(void) {
setlocale(LC_ALL, "portuguese");

	int i, j, k;
	int mat [3][4];
	for (i=0; i<3; i++) {
		for (j=0; j<4; j++) {
			printf ("Digite o valor da posicao %d, %d: ", i, j);
			scanf ("%d", &mat[i][j]);
		}
	}
	system("cls");
	for (i=0; i<3; i++) {
		for (j=0; j<4; j++){
			printf ("\t%d", mat[i][j]);
			printf (" ");
		}
	printf ("\n");
	}


}