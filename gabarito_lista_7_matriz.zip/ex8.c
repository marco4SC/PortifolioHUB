/*
8.
Crie um Algoritmo para ler 25 nomes digitados pelo usuário e imprimir o nome caso este seja 'maria', informando que posição (linha) este se encontra dentro da matriz.
a) Converta todos os caracteres digitados para maiúsculas sem utilizar uma função para isso. Observe a tabela ASCII.
b) Conte o total de caracteres convertidos para maiúsculos e apresente o valor no fi-nal.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <stdlib.h>


void main(void) {
	setlocale(LC_ALL, "portuguese");
	int i, j=0;
	char nome[25][40];
	printf("\n para encerrar a entrada de nome digite ctrl [ e <ENTER>");
	for (i=0; i<25; i++) 
		{	printf("\n Digite seu nome: ");
			gets(nome[i]);
			if(nome[i][0]==27)
				break;
			j=0;
			while(nome[i][j]!=0){
				nome[i][j]-=0x20;
			j++;
			}
}
	j=i;
	for (i=0; i<j; i++) {
		if((strcmp(nome[i],"MARIA")==0))
	 		printf("\n O nome %s se encontra no elemento %d", nome[i],i);
		
		for (i=0; i<j; i++) 
			puts(nome[i]);
	
}
}
