/*
9.
Faça um programa que:
a) Leia uma matriz 3x3 de números inteiros.
b) Imprima-a em formato matricial.
c) Leia um número inteiro k.
d) Atualize a matriz com seu valor multiplicado por k, e imprima-a no formato matricial.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <stdlib.h>

void main(void) {
setlocale(LC_ALL, "portuguese");

	int i, j, fator=0;
	int mat [3][3];
	for (i=0; i<3; i++) {
		for (j=0; j<3; j++) {
			printf ("Digite o valor da posicao %d, %d: ", i, j);
			scanf ("%d", &mat[i][j]);
		}
	}
	system("cls");
	for (i=0; i<3; i++) {
		for (j=0; j<3; j++){
			printf ("\t%d", mat[i][j]);
			printf (" ");
		}
	printf ("\n");

	}
	printf("\nDigite um fator multiplicador para a matriz: ");
	scanf("%d",&fator);
	for (i=0; i<3; i++) 
		for (j=0; j<3; j++)
			mat[i][j]*=fator;
			
		for (i=0; i<3; i++) {
		for (j=0; j<3; j++){
			printf ("\t%d", mat[i][j]);
			printf (" ");
		}
	printf ("\n");

	}	

}