/*
2.
No programa anterior, nós percorremos a matriz linha por linha, ou seja, fixamos o valor da linha e variamos a coluna.
 Agora vamos refazê-lo percorrendo a matriz coluna por coluna, ou seja, fixamos o valor da coluna e variamos a linha.
 No final mostre os valores armazenados na matriz.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <stdlib.h>

void main(void) {
setlocale(LC_ALL, "portuguese");

	int i, j, k;
	int mat [3][4];
		for (j=0; j<4; j++)
		for (i=0; i<3; i++) {
	 {
			printf ("Digite o valor da posicao %d, %d: ", i, j);
			scanf ("%d", &mat[i][j]);
		}
	}
	system("cls");
	for (i=0; i<3; i++) {
		for (j=0; j<4; j++){
			printf ("\t%d", mat[i][j]);
			printf (" ");
		}
	printf ("\n");
	}


}