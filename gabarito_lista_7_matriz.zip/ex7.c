/*
7.
Na matriz 4 x 5 do problema quatro, selecione a linha que tem o maior total, ou seja,
 soma dos valores da linha. No final mostre o maior total encontrado e em qual linha ele se encontra.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <stdlib.h>

void main(void) {
	setlocale(LC_ALL, "portuguese");
	int i, j=0,max=0,k=0;
	int m1[4][5]={0},soma[4]={0};
	for (i=0; i<4; i++) 
			for (j=0; j<5; j++){
	 
			printf ("Digite o valor da posicao %d, %d: ", i, j);
			scanf ("%d", &m1[i][j]);
	}
	for (i=0; i<4; i++) {
		for (j=0; j<5; j++)
	 	{
			soma[i]=soma[i]+m1[i][j];
		}
		if (soma[i]>max){

			max= soma[i];
			k=i;
}
}
	printf ("\n A maior soma é %d e está na linha %d", max,k) ;

}