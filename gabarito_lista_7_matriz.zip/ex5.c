/*
5.
Somar uma matriz por coluna, ou seja, obter o total de cada coluna da matriz. 
No final ge-re uma tela de saída mostrando esses valores e o 
total geral de toda a matriz. Use uma matriz 4 x 5.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <stdlib.h>

void main(void) {
	setlocale(LC_ALL, "portuguese");
	int i, j;
	int m1[4][5]={0},soma[5]={0};
	for (j=0; j<5; j++)
	for (i=0; i<4; i++) 
	
	{
	 
			printf ("Digite o valor da posicao %d, %d: ", i, j);
			scanf ("%d", &m1[i][j]);
	}
	for (j=0; j<5; j++) 
			for (i=0; i<4; i++)
	 {
			soma[j]=soma[j]+m1[i][j];
		}
	system("cls");
	for (i=0; i<4; i++, printf("\n") )
		for (j=0; j<5; j++)
					printf ("\t%d", m1[i][j]);
	for (j=0; j<5; j++, printf ("\n Total coluna %d = %d", j,soma[j-1]) );
		
	for (j=0,i=0; i<5; i++) 
				j += soma[i];
	printf ("\n A soma de todos os elementos da matriz é  Total linha = %d\n", j) ;

	

}