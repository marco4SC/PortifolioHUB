/*
10. O tempo que um determinado avião dispensa para percorrer o trecho entre duas localida-des distintas está disponível através da seguinte tabela:
Osgliath
Minas Tirith
Edoras Isengard Esgaroth The Shire
Valfenda
Osgliath

Utilizando os dados da tabela acima, construa um programa que informe ao usuário o tempo necessário para percorrer 
duas cidades por ele fornecidas. O programa deverá mostrar um menu com as cidades existentes e o usuário fornecerá o número ou o códi-go das cidades origem e destino.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
void main(void) {
setlocale(LC_ALL, "portuguese");

	int i, j, fator=0, op1,op2;
	char cidades[][20]={"Osgliath","Minas Tirith","Edoras","Isengard","Esgaroth", "The Shire", "Valfenda"}, aux[10];
	int mat [][7]={{0, 2,11,6,15,11,1},{2,0,7,12,4,2,15},{11,7,0,11,8,3,13},{6,12,11,0,10,2,1},{15,4,8,10,0,5},{11,2,3,2,5,0,14},{1,15,13,1,13,14,0}};

printf("\n                                             Bem-vindo à Terra Média \nSelecione uma opção:");
printf("\n1 - Osgliath\n2 - Minas Tirith \n3 - Edoras\n4 - Isengard\n5 - Esgaroth\n6 - The Shire\n7 - Valfenda");
printf("\nSelecione origem:");
op1=atoi(gets(aux));
printf("\nSelecione destino:");
op2=atoi(gets(aux));
printf("\n %d  %d",op1,op2);
printf("\n A distância entre %s e %s é de %d",cidades[op1-1],cidades[op2-1],mat[op1-1][op2-1]);

}