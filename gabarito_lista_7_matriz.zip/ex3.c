/*
3.
Construa um programa que efetue a leitura, a soma posicional e a impressão do resultado,
 entre duas matrizes inteiras que comportem 25 elementos. Use uma terceira matriz pa-ra armazenar o resultado.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <stdlib.h>

void main() {
setlocale(LC_ALL, "portuguese");

	int i, j, k;
	int m1[5][5]={0},m2[5][5]={0},m3[5][5]={0};
		
	for (i=0; i<5; i++) 
			for (j=0; j<5; j++){
	 
			printf ("Digite o valor da posicao %d, %d: ", i, j);
			scanf ("%d", &m1[i][j]);
	
	}
	for (i=0; i<5; i++) 
			for (j=0; j<5; j++)
	 {
			printf ("Digite o valor da posicao %d, %d: ", i, j);
			scanf ("%d", &m2[i][j]);
		}
	
	for (i=0; i<5; i++) 
		for (j=0; j<5; j++)
			m3[i][j]=m1[i][j]+m2[i][j];
		
	system("cls");
	for (i=0; i<5; i++) {
		for (j=0; j<5; j++){
			printf ("\t%d", m3[i][j]);
			printf (" ");
		}
	printf ("\n");
	}


}