/*
6.
Refaça o problema quatro para obter a média aritmética dos valores de cada linha. 
No fi-nal exiba um relatório com o número da linha e o correspondente valor calculado.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <stdlib.h>

void main(void) {
	setlocale(LC_ALL, "portuguese");
	int i, j;
	int m1[4][5]={0},med[4]={0};
	for (i=0; i<4; i++) 
			for (j=0; j<5; j++){
	 
			printf ("Digite o valor da posicao %d, %d: ", i, j);
			scanf ("%d", &m1[i][j]);
	}
	for (i=0; i<4; i++) 
			for (j=0; j<5; j++)
	 {
			med[i]=med[i]+m1[i][j];
			
		}

	for (i=0; i<4; i++ )
		for (printf("\n"),j=0; j<5; j++)
					printf ("\t%d", m1[i][j]);
	for (i=0; i<4; i++) 
			printf ("\n A media dos valores da linha %d é %d", i, med[i]/5) ;

}