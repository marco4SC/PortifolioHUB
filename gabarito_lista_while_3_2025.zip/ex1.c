/* 1. Elaborar um programa C para computar a média de N números reais. */
#include <stdio.h>
#include <locale.h>
void main(void)
{   int n=0,div=0;
	float num=0,acc=0;
    setlocale(LC_ALL,"portuguese");
	printf("\n Quantos números deseja calcular a média?");
	scanf("%d",&n);
	div=n;
	while(n>0)
	{
	printf("\n digite o número %d :", n-(n-1));
	scanf("%f", &num);
    acc+=num;
	n--;
	}
    
    printf("\nA média é %.2f",(float)acc/div);

}
