/* 5. Desenvolva um programa que leia vários números digitados pelo usuário 
e use o valor -1 como condição (flag) de saída da estrutura de repetição. 
Na tela de saída, mostre a quantidade de números digitados.

Teste 1: Entrada: 5, 6 e -1 Saída: Quantidade de números: 2
Teste 2: Entrada: 5, 6, 7 e -1 Saída: Quantidade de números: 3
Teste 3: Entrada: 5, 6, 6, 7 e -1 Saída: Quantidade de números: 4

ALTERAÇÕES:
a.
Na tela de saída, acrescente a soma dos valores digitados. */

#include <stdio.h>
#include <locale.h>
void main(void)
{   int i=0,n=0;
    setlocale(LC_ALL,"portuguese");
    
    while(n!= -1) {
		printf("\nEntre com um número %d:",i+1);
    	scanf ("%d", &n);
        i++;
         }
    printf("\nA Quantidade de números digitados foi %d",i-1);
    
}
