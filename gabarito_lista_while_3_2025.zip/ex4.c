/* 4. Faça um programa que calcula a média aritmética de uma turma com cinquenta alunos, 
sabendo-se que cada aluno realizou uma avaliação. Para facilitar os testes, faça com quatro alunos.
Teste 1: notas: 2, 3, 4 e 5
Saída: Média da turma = 3.5
ALTERAÇÕES:
a. Troque a mensagem de entrada estática do input por uma mensagem dinâmica:
Digite a nota do aluno número X:
b. Mostre a média da turma com duas casas decimais */
#include <stdio.h>
#include <locale.h>
void main(void)
{   int i=0;
    float nota=0,acc=0;
    setlocale(LC_ALL,"portuguese");
    
    while(i<50) {
		printf("\nEntre com a nota do aluno número %d:",i+1);
    	scanf ("%f", &nota);
        acc += nota;
		i++;
         }
    printf("\nA média é %.2f",acc/50.0);
    
}
