/* 3. Sabendo que a fórmula de conversão de graus Fahrenheit para Celsius é: C = ( 5 / 9 ) * ( f – 32 ), 
escreva um programa que converta de Fahrenheit para Celsius exiba na tela as temperaturas compreendidas 
em um intervalo a ser fornecido pelo usuário. O usuário deverá fornecer o valor inicial e o valor final.
 O programa então exibirá as temperaturas compreendidas no intervalo, devendo exibir as duas unidades de conversão.
 programa deverá exibir o seguinte cabeçalho. O programa deverá exibir o seguinte cabeçalho.

              CONVERSAO FAHREINHEIT – CELSIUS
CELSIUS                                               FAHREINHEIT 
*/
#include <stdio.h>
#include <locale.h>
void main(void)
{   int cont=0;
	float fi=0, ff=0,c=0;
    setlocale(LC_ALL,"portuguese");
	printf("\n Informe a temperatura inicial em °F :");
	scanf("%f",&fi);
	printf("\n Informe a temperatura final em °F :");
	scanf("%f",&ff);
	printf("\n              CONVERSAO FAHREINHEIT – CELSIUS");
	printf("\nCELSIUS                                               FAHREINHEIT ");
	while(fi<=ff)
	{
	c = ( 5.0 / 9.0 ) * ( fi - 32.0 );
	printf("\n %.2f                                                    %.2f", c,fi);
	fi++;
	cont++;
	}
    
    
}
