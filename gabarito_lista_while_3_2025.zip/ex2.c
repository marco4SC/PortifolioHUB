/* 2. Sabendo que a fórmula de conversão de graus Fahrenheit para Celsius é:
C = ( 5 / 9 ) * ( f – 32 ), escreva um programa que converta de Fahrenheit para Celsius e exiba na tela os 20 (vinte) primeiros
 valores a partir da temperatura de 32° F , devendo exibir as duas unidades de conversão. programa deverá exibir o seguinte cabeçalho.
              CONVERSAO FAHREINHEIT – CELSIUS
CELSIUS                                               FAHREINHEIT 
*/
#include <stdio.h>
#include <locale.h>
void main(void)
{   int cont=0;
	float f=32,c=0;
    setlocale(LC_ALL,"portuguese");
	printf("\n              CONVERSAO FAHREINHEIT – CELSIUS");
	printf("\nCELSIUS                                               FAHREINHEIT ");
	while(cont<=20)
	{
	c = ( 5.0 / 9.0 ) * ( f - 32.0 );
	printf("\n %.2f                                                    %.2f", c,f);
	f++;
	cont++;
	}
    
    
}
