/* 6. Construa um programa que imprime a soma de todos os valores positivos digitados
 pelo usuário até que ele digite um número negativo. (resolva com Do-While) */

#include <stdio.h>
#include <locale.h>
void main(void)
{   int i=0,n=0,acc=0;
    setlocale(LC_ALL,"portuguese");
    
    do {
		printf("\nEntre com um número %d:",i+1);
    	scanf ("%d", &n);
		acc+=n;
        i++;
         }while(n!= -1);
    printf("\nA soma dos números digitados foi %d",acc+1);
    
}
