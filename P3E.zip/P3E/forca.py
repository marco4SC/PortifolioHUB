# Preencha a lista com os números mecanográficos dos autores.
AUTORES = [119139, 115785] 
GRUPO = ["P3E"]

import random
import os
import sys

# Defina funções aqui.

def draw_person(errors):
    """Desenha o boneco baseado em errors."""

    person_states = [
    f"""




 _______
""",
    """

|
|
|
|_______
""",
    """
_____
|
|
|
|_______
""",
    """
_____
|    O
|
|
|_______
""",
    """
_____
|    O
|    |
|
|_______
""",
    """
_____
|    O
|   /|
|
|_______
""",
    """
_____
|    O
|   /|\\
|
|_______
""",
    """
_____
|    O
|   /|\\
|   /
|_______
""",
    f"""
_____
|   {chr(128565)}
|   /|\\
|   / \\
|_______
"""
    ]
    print(person_states[errors])


def input_guess(available_letters):
    """Pede uma letra e verifica se esta é válida ou se já tinha sido dita."""
    
    while True:
        guess = input("Diz uma letra: ").upper().strip()
        
        if not guess.isalpha() or len(guess) != 1:
            print("Letra inválida!")
        elif guess in available_letters:
            break
        else:
            print("Letra repetida!")
    return guess


def check_letter(guess, show_word, no_accents_word, secret):
    """Verifica se guess é igual à letra de no_accents_word em cada posição, atualizando show_word."""

    for index in range(len(no_accents_word)):
        if guess == no_accents_word[index]:
            show_word[index] = secret[index]


def remove_accents(word):
    """Remove acentos e cedilhas das palavras e substitui pelas letras não acentuadas."""

    new_word = list(word)

    # Listas dos caracteres com acentos para cada vogal
    list_a = ["Á", "À", "Ã", "Â", "Ä"]
    list_e = ["É", "È", "Ê", "Ë"]
    list_i = ["Í", "Ì", "î", "Ï"]
    list_o = ["Ó", "Ò", "Õ", "Ô", "Ö"]
    list_u = ["Ú", "Ù", "Û", "Ü"]
    
    for index in range(len(new_word)):
        if new_word[index] in list_a:
            new_word[index] = "A"
        if new_word[index] in list_e:
            new_word[index] = "E"
        if new_word[index] in list_i:
            new_word[index] = "I"
        if new_word[index] in list_o:
            new_word[index] = "O"
        if new_word[index] in list_u:
            new_word[index] = "U"
        if new_word[index] == "Ç":
            new_word[index] = "C"

    return new_word


def print_list(lst, separation=""):
    """Escreve todos os elementos de lst com separation a separá-los."""

    for index in range(len(lst)):
        if index == len(lst)-1:
            print(lst[index])
        else:
            print(lst[index], end=separation)
    
    # Um print() para impedir desformatações quando a lista está vazia.
    if len(lst) == 0:
        print()


def clear_terminal():
    """Limpa o terminal."""
    
    if sys.platform == "win32":
        os.system("cls")
    else:
        os.system("clear")


def menu():
    """Escreve o título do programa e apresenta 2 opções ao jogador."""
    
    print ("""
::::::'##::'#######:::'######::::'#######::'########:::::'###::::'########::'#######::'########:::'######:::::'###::::
:::::: ##:'##.... ##:'##... ##::'##.... ##: ##.... ##:::'## ##::: ##.....::'##.... ##: ##.... ##:'##... ##:::'## ##:::
:::::: ##: ##:::: ##: ##:::..::: ##:::: ##: ##:::: ##::'##:. ##:: ##::::::: ##:::: ##: ##:::: ##: ##:::..:::'##:. ##::
:::::: ##: ##:::: ##: ##::'####: ##:::: ##: ##:::: ##:'##:::. ##: ######::: ##:::: ##: ########:: ##:::::::'##:::. ##:
'##::: ##: ##:::: ##: ##::: ##:: ##:::: ##: ##:::: ##: #########: ##...:::: ##:::: ##: ##.. ##::: ##::::::: #########:
 ##::: ##: ##:::: ##: ##::: ##:: ##:::: ##: ##:::: ##: ##.... ##: ##::::::: ##:::: ##: ##::. ##:: ##::: ##: ##.... ##:
. ######::. #######::. ######:::. #######:: ########:: ##:::: ##: ##:::::::. #######:: ##:::. ##:. ######:: ##:::: ##:
:......::::.......::::......:::::.......:::........:::..:::::..::..:::::::::.......:::..:::::..:::......:::..:::::..::\n""")
    
    
    jogar = input("Escolhe uma opção:\n1. Jogar\t2. Instruções\n").upper().strip()
    if jogar == "1":
        print("Vamos começar! ")
    elif jogar == "2":
        clear_terminal()
        input ("O objetivo deste jogo é descobrir uma palavra através das suas letras, sem deixar o boneco morrer.\nNeste jogo terás 8 tentativas para adivinhar a palavra, dizendo uma das suas letras de cada vez.\nSe a letra não fizer parte da palavra, então contará como um erro.\nCada erro representa parte da forca ou do boneco.\nLetras repetidas ou inválidas não serão contabilizadas.\n\nPressiona enter para voltar.\n")
        clear_terminal()
        menu()
    else:
        print("Por favor apenas utiliza 1 ou 2.\n")
        menu()


def execute_game(secret):
    """Executa um jogo da forca, em que secret é a palavra a adivinhar."""

    # Lista com os caracteres que vão ser mostrados ao jogador
    show_word = list("_"*len(secret))
    
    # Lista com a palavra que vai ser adivinhada, mas sem os acentos
    no_accents_word = remove_accents(secret)

    # Letras que o jogador já errou
    wrong_letters = []

    # Letras que o jogador ainda não tentou adivinhar
    available_letters = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]

    errors = 0
    while True:
        clear_terminal()

        draw_person(errors)
        print_list(show_word, " ")
        print(f"\n\nERROS: {errors}\n")
        print("Letras por usar: ", end="")
        print_list(available_letters, ", ")
        print("Letras erradas: ", end="")
        print_list(wrong_letters, ", ")
        print()

        # Condições de vitória e derrota
        if errors >= 8:
            print(f"""
                  
██▓███  ▓█████  ██▀███  ▓█████▄ ▓█████   ██████ ▄▄▄█████▓▓█████ 
▓██░  ██▒▓█   ▀ ▓██ ▒ ██▒▒██▀ ██▌▓█   ▀ ▒██    ▒ ▓  ██▒ ▓▒▓█   ▀ 
▓██░ ██▓▒▒███   ▓██ ░▄█ ▒░██   █▌▒███   ░ ▓██▄   ▒ ▓██░ ▒░▒███   
▒██▄█▓▒ ▒▒▓█  ▄ ▒██▀▀█▄  ░▓█▄   ▌▒▓█  ▄   ▒   ██▒░ ▓██▓ ░ ▒▓█  ▄ 
▒██▒ ░  ░░▒████▒░██▓ ▒██▒░▒████▓ ░▒████▒▒██████▒▒  ▒██▒ ░ ░▒████▒
▒▓▒░ ░  ░░░ ▒░ ░░ ▒▓ ░▒▓░ ▒▒▓  ▒ ░░ ▒░ ░▒ ▒▓▒ ▒ ░  ▒ ░░   ░░ ▒░ ░
░▒ ░      ░ ░  ░  ░▒ ░ ▒░ ░ ▒  ▒  ░ ░  ░░ ░▒  ░ ░    ░     ░ ░  ░
░░          ░     ░░   ░  ░ ░  ░    ░   ░  ░  ░    ░         ░   
            ░  ░   ░        ░       ░  ░      ░              ░  ░
                          ░                                      
            \nA palavra era {secret}.""")
            break
        elif secret == "".join(show_word): # "".join(show_word) "converte" show_word em string
            print("""
                  
 $$$$$$\   $$$$$$\  $$\   $$\ $$\   $$\  $$$$$$\   $$$$$$\ $$$$$$$$\ $$$$$$$$\ 
$$  __$$\ $$  __$$\ $$$\  $$ |$$ |  $$ |$$  __$$\ $$  __$$\\__$$  __|$$  _____|
$$ /  \__|$$ /  $$ |$$$$\ $$ |$$ |  $$ |$$ /  $$ |$$ /  \__|  $$ |   $$ |      
$$ |$$$$\ $$$$$$$$ |$$ $$\$$ |$$$$$$$$ |$$$$$$$$ |\$$$$$$\    $$ |   $$$$$\    
$$ |\_$$ |$$  __$$ |$$ \$$$$ |$$  __$$ |$$  __$$ | \____$$\   $$ |   $$  __|   
$$ |  $$ |$$ |  $$ |$$ |\$$$ |$$ |  $$ |$$ |  $$ |$$\   $$ |  $$ |   $$ |      
\$$$$$$  |$$ |  $$ |$$ | \$$ |$$ |  $$ |$$ |  $$ |\$$$$$$  |  $$ |   $$$$$$$$\ 
 \______/ \__|  \__|\__|  \__|\__|  \__|\__|  \__| \______/   \__|   \________|
""")
            break
  
        
        guess = input_guess(available_letters)
        
        if guess in available_letters:
            available_letters.remove(guess)

        # Se a letra não fizer parte da palavra(sem acentos) e se não estiver na lista de palavras erradas, então é um novo erro
        if not guess in no_accents_word and not guess in wrong_letters:
            errors += 1
            wrong_letters.append(guess)
            wrong_letters.sort()
        else:
            check_letter(guess, show_word, no_accents_word, secret)

def main():
    from wordlist import words1, words2
    
    # Descomente a linha que interessar para testar
    #words = words1              # palavras sem acentos nem cedilhas.
    #words = words2             # palavras com acentos ou cedilhas.
    words = words1 + words2    # palavras de ambos os tipos
    
    if len(sys.argv) > 1:       # correr o programa com palavras dadas:
        words = sys.argv[1:]    #   python3 forca.py duas palavras

    # Complete o programa

    # Loop principal
    while True:
        clear_terminal()
        menu()
        clear_terminal()

        # Executa o jogo com uma palavra aleatória
        execute_game(random.choice(words).upper())
        
        # Loop para jogar outra vez
        while True:
            restart = input("Queres jogar de novo? ").upper().strip()

            # Palavras equivalentes a sim e a não, respetivamente
            teste_sim = ["SIM", "S", "YES", "Y"]
            teste_nao = ["NAO", "N", "NO", "NÃO"]
            
            if restart in teste_sim:
                break
            elif restart in teste_nao:
                print("Ok...")
                exit()
            else:
                print("Ou é sim ou é não!")


if __name__ == "__main__":
    main()

