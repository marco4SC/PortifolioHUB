# Preencha a lista com os números mecanográficos dos autores.
AUTORES = [119809 , 118929]

import random
import sys                  # INCLUA estas 3 linhas para permitir
if len(sys.argv) > 1:       # correr o programa com palavras dadas:
        words = sys.argv[1:]    #   python3 forca.py duas palavras

# Defina funções aqui.
...


def main():
    from wordlist import words1, words2
    
    # Descomente a linha que interessar para testar
    words = words1              # palavras sem acentos nem cedilhas.
    #words = words2             # palavras com acentos ou cedilhas.
    #words = words1 + words2    # palavras de ambos os tipos

    # Escolhe palavra aleatoriamente
    secret = random.choice(words).upper()

    # Complete o programa
    erros = 0 
    lista_de_letras_usadas = []

    while erros <= 5 :
        print("")
        
        if erros == 0:
            print(" ")
            print("-------")
            print("|")
            print("| ")
            print("|")
            print("| ")
            print("|__________")
            print(" ")
        print("")
        guess = input("Adivinhe uma letra?")
        guess = guess.upper()
        if guess in lista_de_letras_usadas :
           print(" ")
           print("!! Letra:",guess,"já usada !! <----------")

        


        lista = list(secret)
        if guess not in lista:
            erros = erros + 1


        if erros >= 1:                  ## Imprime o boneco
            print("_______")    
            print("|")
        if erros >= 1:
            print("|  O  ")
        if erros >= 2:
            print("| /", end="")
        if erros >= 3:
            print("|",end ="")              
        if erros >= 4:
            print("\\")
            print("|", end="")
        if erros >= 5:
            print(" /",end="")
            print(" ",end="")
        if erros == 6 :
            print("\\")
            print("|__________")  
            print("<<<<  GAME OVER  >>>>")
            print("A palavra secreta era:", secret)
            break

        print(" ")
        print(" ")
        print("ERROS:", erros)


        temp = []
        
        for letra in lista:                                                       ## memoriza se a letra ja foi usada 
            if (guess == letra) and not (guess in lista_de_letras_usadas):
                print(letra,end="")
                temp.append(letra)
                lista_de_letras_usadas.append(guess)
            elif letra in lista_de_letras_usadas:                   ## imprime letras usadas e espacos em branco
                temp.append(letra)
                print(letra, end="")
            else:
                print("_",end="")
            if int(len(temp))== int(len(secret)) :                      ## deteta se o jogador venceu o jogo
                print("<<<<<<<<<   VENCEU!!   >>>>>>>>>")
                erros = 10
                break
        

if __name__ == "__main__":
    main()

