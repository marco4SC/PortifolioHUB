/*
Escreva um programa que leia números inteiros do teclado.
 O programa deve ler os números até que o usuário digite 0(zero).
 No final da execução, exiba a quantidade de números digitados,
 assim como a soma e a média aritmética.
*/
#include <stdio.h>
void main(void)
{
	int n=1,soma=0,cont=0;
while(n!=0){
printf("digite um numero: ");
scanf("%d",&n);	
soma+=n;
cont+=1;

}
cont-=1;
printf("a soma dos numeros e %d",soma);
printf("A media e %d",soma/cont);
}
