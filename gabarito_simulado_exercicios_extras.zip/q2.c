#include <stdio.h>
void main(void)
{
	int idade;
printf("digite a sua idade:");
scanf("%d",&idade);
if (idade >= 5 &&  idade <11)
    printf("categoria Infantil");
else if (idade >= 11 &&  idade <18)
    printf("categoria Juvenil");
else if (idade >= 18 &&  idade <41)
    printf("categoria Adulto");    
else if (idade >40)
    printf("categoria Veterano");   
}