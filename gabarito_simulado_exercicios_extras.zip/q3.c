#include <stdio.h>
void main(void)
{
	int i, soma =0;
for(i=1; i<=100;i++)
 soma+=i;
printf("O valor do somatorio e %d",soma);
}
