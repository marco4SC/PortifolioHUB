/*
Escreva um programa que leia um número e verifique se é ou não
um número primo. Para fazer essa verificação, calcule o resto 
da divisão do número por 2 e depois por todos os números 
ímpares até o número lido. Se o resto de uma dessas divisões 
for igual a zero, o número não é primo. Observe que 0 e 1 não 
são primos e que 2 é o único número primo que é par.
*/
#include <stdio.h>
void main(void)
{
	int n,limite;
printf("digite um numero: ");
scanf("%d",&n);
limite = n;
n =2;
while (n<limite)
{
    if (limite ==2 || limite < 2)
        break;
    if (limite % n ==0)
        break;
    n+=1;
    if (n % 2 ==0)
        n+=1;
}
if ( n == limite)
    printf("primo");
else
    printf("nao primo");
}