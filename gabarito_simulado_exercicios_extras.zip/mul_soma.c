/*
Escreva um programa que leia dois números. 
Imprima o resultado da multiplicação do primeiro 
pelo segundo. Utilize apenas os operadores 
de soma e subtração para calcular o resultado. 
Lembre-se de que podemos entender a multiplicação
 de dois números como somas sucessivas de um deles.
 Assim, 4 × 5 = 5 + 5 + 5 + 5 = 4 + 4 + 4 + 4 + 4
*/

#include <stdio.h>
void main(void)
{
	int multi,multn,mul=0,i;
printf("digite um numero: ");
scanf("%d",&multn);
printf("digite um numero: ");
scanf("%d",&multi);
mul=0;
for(i=0; i<multi;i++)
	mul+=multn;
printf("\n%d ",mul);
}