#include <stdio.h>
void main(void)
{
	float pi=3.141516, volume, raio;
printf("informe o valor do raio do hemisferio: ");
scanf("%f",&raio);
volume = (2.0/3.0) * pi * (raio*raio*raio);
printf("O volume do hemisferio e %.2f",volume);
}