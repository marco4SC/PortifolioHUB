#include <stdio.h>
#include <locale.h>
void main (void)
{setlocale(LC_ALL,"portuguese");
int cont, tomai(char vet[]);
char aux[10],nome[40];
printf("\n Digite um nome: ");
gets(nome);
cont=tomai(nome);
printf("\n Foram realizadas %d convers�es de caracteres de min�sculo para mai�sculo.",cont);
printf("\n O nome em mai�sculas � %s",nome);
}

int tomai(char vet[])//converte vetor nome de minusculo para maiusculo e conta
{int i=0,cont=0;
for(i=0;vet[i]!=0;i++){

	if(vet[i]>96)//se o caracter for minusculo converto
	{
	vet[i]-=32;//32 � o valor constante da diferen�a entre letras maiusculas
	cont++;// e minusculas. de minusculo para mai�sculo eu sibtraio 32
	}
}
return(cont);
}
	
