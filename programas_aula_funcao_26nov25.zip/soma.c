#include <stdio.h>
#include <conio.h>
void main(void)
{
int a , b , c ;
int soma( int x , int y);
printf("\ndigite o primeiro n�mero a ser somado: ");
scanf("%d" , &a);
printf("\ndigite o segundo n�mero a ser somado: ");
scanf("%d" , &b);
c= soma( a , b );
printf(" \no resultado da soma de %d com %d � %d", a , b , c);
}

int soma ( int x , int y )
{
int result;
result = x + y ;
return( result );
}

