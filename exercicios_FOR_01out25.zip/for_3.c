#include <stdio.h>
//void main(void)
//{  int i,j;
//for( i=1; i<=10; i++)
// for(printf("\n Tabuada do %d",i), j=1; j<=10;printf("\n%d X d% = %d",i,j,i*j), j++);
			
//}


#include <stdio.h>
void main(void)
{  int i,j;
for( i=1; i<=10; i++)
	{
	printf("\n Tabuada do %d",i);
 	for(j=1; j<=10; j++)
  		printf("\n%d X d% = %d",i,j,i*j);
	}
}
