#include <stdio.h>
void main(void)
{  int i;
for( i=100; i>=0; i--)
	if((i%2==1)&&(i%3==0))
			printf("\n%d",i);
}
