#include <stdio.h>
void main(void)
{  int i, n;
//entrar com o dado, limite superior do la�o for
  printf("\nEntre com o n�mero:");
  scanf ("%d", &n);

  for (printf("\n                   Dec,    Oct,   Hex"), i=1; i<=n; i++)
   {
     if ((i%7)==0)
       printf("\nn�mero par -------> %4d,    %4o,    %0X", i,i,i);
  }
  printf("\nFIM");
}
