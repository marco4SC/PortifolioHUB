# Preencha a lista com os números mecanográficos dos autores.
AUTORES = [110235, 121420]

import random
import unicodedata
# Defina funções aqui.
...


def hangman(secret_word):
    guessed_letters = []
    attempts = 7
    # Normalize the secret word
    normalized_secret_word = unicodedata.normalize('NFD', secret_word)

    print("Let's play Hangman!")
    print("_ " * len(secret_word))

    while attempts > 0:
        guess = input("Guess a letter: ").upper()
        # Normalize the guess
        normalized_guess = unicodedata.normalize('NFD', guess)

        if guess in guessed_letters:
            print("You already guessed that letter.")
        elif normalized_guess not in normalized_secret_word:
            drawSticker(attempts)
            print("That letter is not in the word.")
            attempts -= 1
            drawSticker(attempts)
        else:
            print("Good job! That letter is in the word.")
            guessed_letters.append(guess)

        word_so_far = ""
        for i, letter in enumerate(normalized_secret_word):
            if letter in guessed_letters or unicodedata.normalize('NFD', letter) in guessed_letters:
                word_so_far += secret_word[i] + " "
            else:
                word_so_far += "_ "

        print(word_so_far)
        print(f"You have {attempts} attempts left.")

        if "_" not in word_so_far:
            print("Congratulations! You guessed the word.")
            return

    print("Sorry, you didn't guess the word. Better luck next time!")



def drawSticker(error):
    # function to print the hangman figure
    if error == 6:
        print("____")
        print("|  |")
        print("|")
        print("|")
        print("|")
        print("|____")
    elif error == 5:
        print("____")
        print("|  |")
        print("|  O")
        print("|")
        print("|")
        print("|____")
    elif error == 4:
        print("____")
        print("|  |")
        print("|  O")
        print("| /")
        print("|")
        print("|____")
    elif error == 3:
        print("____")
        print("|  |")
        print("|  O")
        print("| /|")
        print("|")
        print("|____")
    elif error == 2:
        print("____")
        print("|  |")
        print("|  O")
        print("| /|\ ")
        print("|")
        print("|____")
    elif error == 1:
        print("____")
        print("|  |")
        print("|  O")
        print("| /|\ ")
        print("| /  ")
        print("|____")
    elif error == 0:
        print("____")
        print("|  |")
        print("|  O")
        print("| /|\ ")
        print("| / \ ")
        print("|____")



def main():
    from wordlist import words1, words2
    
    # Descomente a linha que interessar para testar
    words = words1              # palavras sem acentos nem cedilhas.
    #words = words2             # palavras com acentos ou cedilhas.
    #words = words1 + words2    # palavras de ambos os tipos

    import sys                  # INCLUA estas 3 linhas para permitir
    if len(sys.argv) > 1:       # correr o programa com palavras dadas:
        words = sys.argv[1:]    #   python3 forca.py duas palavras
        
    # Escolhe palavra aleatoriamente
    secret = random.choice(words).upper()

    # Complete o programa
    ...
    hangman(secret)


if __name__ == "__main__":
    main()
