/*
1. Elaborar um programa C para computar a m�dia de N n�meros reais. 
Voc� receber� um n�mero real e ir� realizar a soma dele com todos 
os seus antecessores at� chegar a zero.
*/
#include <stdio.h>
#include <stdlib.h>
void main(void)
{
	float num,soma=0,media=0;
	int i,qtd;
	printf("\n Informe quantos numeros para calcular: ");
	scanf("%d",&qtd);
	for(i=0;i<qtd;i++)
	{
		printf("\n Digite o numero: ");
		scanf("%f",&num);
		soma+=num;
	}
	media = soma/(float)qtd;
	printf("\n a soma dos valores e %.2f\n A media dos valores e %.2f",soma,media);
}
	
