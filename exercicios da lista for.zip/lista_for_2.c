/*
2. Fa�a um programa que imprime todos os n�meros entre 30 e 5
 (nesta ordem) divis�veis por 3, e no final imprime sua soma. 
 */
#include <stdio.h>
#include <stdlib.h>
void main(void)
{ int i,soma=0;
for(i=30;i>=5;i--)
	{
		if(i%3==0)
			{
				printf("  %d",i);
				soma+=i;
			}
	}
	printf("\n A soma dos valores divisiveis por 3 e %d",soma);
}
