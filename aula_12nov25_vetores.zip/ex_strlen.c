#include <stdio.h>
#include <locale.h>
#include <string.h>
void main(void)
    {
     int i;
	 char vet[]="ceub";
     i= strlen(vet);
     printf("\n O tamanho do vetor vet = %d ",strlen(vet));
		 
}

