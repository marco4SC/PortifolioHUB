#include <stdio.h>
#include <string.h>
void main (void) {
   char vet[80]="22222";
   sprintf(vet, "Value of Pi = %f", 3.141516);
   puts(vet);
   }

