#include <stdio.h>
#include <locale.h>
#include <string.h>
void main(void)
    {   int i;
	 char vet[40],vet1[40]="Centro Universit�rio de Bras�lia";
	 setlocale(LC_ALL,"portuguese");
   printf("\n Digite uma frase:");
	gets(vet); 
	strcat(vet1,vet); //concatena o vetor vet em vet1, ao final 
	//o vetor vet ter� o tamanho do vetro vet1+vet
	puts(vet1);
	puts(vet);

}

