#include <stdio.h>
#include <locale.h>
#include <string.h>
void main(void)
    {   int i;
	 char vet[40],vet1[40]="centro universirario de brasilia";
   printf("\n Digite seu nome:");
	gets(vet); 
	strcpy(vet1,vet); //copia vet em vet1, ao final ambos tem o mesmo valor
	puts(vet1);
	puts(vet);
	//observe que � realizada uma c�pia de vet sobre vet1, dessa forma o vetor vet
	// ir� ser copiado no vetor vet1 , mas os dadosremanescente, se houverem, 
	//n�o ser�o apagados, veja o resultado do teste abaixo
	for (i=0;i<40;printf(" %c ",vet1[i]),i++);

}

