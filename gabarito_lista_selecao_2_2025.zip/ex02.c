/* 2. Faça um programa que leia dois valores quaisquer e mostre o maior deles ou mostre a
mensagem “Os valores são iguais.”
TESTE:
Teste 1: Entrada: 5 e 10 Saída: O maior valor é 10
Teste 2: Entrada: 10 e 5 Saída: O maior valor é 10
Teste 3: Entrada: 5 e 5 Saída: Os valores são iguais.
ALTERAÇÕES:
a. Se eles forem diferentes, mostre os valores digitados na ordem decrescente.
b. Se eles forem iguais, mostre a mensagem e o valor digitado.
*/
#include <stdio.h>
#include <locale.h>

void main (void)
{
	setlocale(LC_ALL,"portuguese");
	int v1=0, v2=0;
	printf("\n Digite o primeiro valor: ");
	scanf("%d",&v1);
	printf("\n Digite o segundo valor: ");
	scanf("%d",&v2);
	if (v1>v2)
		printf("\n O maior valor é %d.",v1);
	else
		if (v1<v2)
			printf("\n O maior valor é %d.",v2);
		else
			printf("\n  Os valores são iguais.");
	
}
	
	
