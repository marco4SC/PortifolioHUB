/* 5. Elabore o programa que verifica se o valor inteiro fornecido pelo usuário é par ou ímpar.
Analise o problema e verifique quais são os dados que o usuário precisa fornecer.
*/
#include <stdio.h>
#include <locale.h>

void main (void)
{
	setlocale(LC_ALL,"portuguese");
	int num=0;
	printf("\n Digite um número: ");
	scanf("%d",&num);
	if ((num%2)==0)
		printf("\n O número é par.");
	else
		printf("\n O número é impar.");
			
}
	
	
