/* 3. Elabore o programa que leia um número qualquer e verifique se ele é positivo, nulo ou negativo.
Teste 1: número = 4 Saída: Número Positivo
Teste 2: número = 0 Saída: Número Nulo
Teste 3: número = -4 Saída: Número Negativo
ALTERAÇÕES:
a. Além da mensagem, mostre também o número digitado pelo usuário.
b. Se o número for positivo, mostre a mensagem, o valor da variável e o dobro de seu valor;
Se negativo, mostre a mensagem, o valor da variável e o seu triplo de seu valor;
Se nulo, mostre a mensagem, o valor da variável número.
*/
#include <stdio.h>
#include <locale.h>

void main (void)
{
	setlocale(LC_ALL,"portuguese");
	int num=0;
	printf("\n Digite um número: ");
	scanf("%d",&num);
	
	if (num>0)
		printf("\n O número %d é positivo e o dobro do seu valor é %d.",num, 2*num);
	else
		if (num<0)
			printf("\n O número %d é negativo e o triplo do seu valor é %d.",num, 3*num);
		else
			printf("\n  O número %d é nulo.",num);
	
}
	
	
