/* 9. Projete o programa que calcule as raízes de uma equação do 2° grau, levando em consideração
a análise da existência de raízes reais. Se o valor de delta for menor que zero, não existem
raízes nos reais; se delta for igual a zero, existem duas raízes iguais; se delta for maior
que zero, existem duas raízes diferentes.
Expressão: ax^2 + bx + c = 0
x = (- b +- raiz_quadrada ( delta ))/2a
delta = (b^2 - 4 a c)
Observação: inclua a biblioteca math.h nas declarações de pré-processamento e utilize a função
sqrt, por exemplo:
float x=4, raizq;
raizq = sqrt(x);
A função pow recebe a base e o expoente e retorna o resultado, veja o exemplo:
int x=2, y=2, pot;
pot = pow(x,y);
*/

#include <stdio.h>
#include <locale.h>
#include <math.h>

void main (void)
{
	setlocale(LC_ALL,"portuguese");
	float a=0,b=0,c=0,delta=0,r1=0,r2=0;
	printf("\n Cálculo das raízes da equação do 2º grau - ax²+bx+c  ");
	printf("\n Digite o coeficiente \"a\": ");
	scanf("%f",&a);
	printf("\n Digite o coeficiente \"b\": ");
	scanf("%f",&b);
	printf("\n Digite o coeficiente \"c\": ");
	scanf("%f",&c);
	delta = (pow(b,2)-(4*a*c));
	if(delta<0.0)
			printf("Não existem raízes reais.");
	else
		{
			if(delta>0.0)
			{
				r1 = ((-b) + sqrt(delta))/(2.0*a);
				r2 = ((-b) - sqrt(delta))/(2.0*a);
				printf("\n As raízes da equação são: %.2f e %.2f",r1,r2);
			}
			else
			{r1 = ((-b) /(2.0*a));
			printf("\n As raízes da equação são iguais e são: %.2f",r1);
			}
		}
	
	
}
	
		
	
