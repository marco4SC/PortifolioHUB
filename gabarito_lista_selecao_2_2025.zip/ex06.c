/* 6. Analise o resultado de uma transação comercial. Verifique a situação final do comerciante
trabalhando com os valores lidos, ou seja, o preço de compra e o preço de venda. Gere a tela
de saída com uma das seguintes mensagens:
“Teve lucro.”, “Teve prejuízo.” ou “Os valores são iguais.”.
Utilize os valores abaixo para testar seu programa:
Teste 1: Entrada: compra = 1000, venda = 1200 Saída: Teve lucro.
Teste 2: Entrada: compra = 1200, venda = 1000 Saída: Teve prejuízo.
Teste 3: Entrada: compra = 1000, venda = 1000 Saída: Os valores são iguais.
Alterações: Na saída, mostre também o valor do preço de compra e do preço de venda.
*/
#include <stdio.h>
#include <locale.h>

void main (void)
{
	setlocale(LC_ALL,"portuguese");
	float compra=0,venda =0;
	printf("\n Digite o valor de compra: ");
	scanf("%f",&compra);
	printf("\n Digite o valor de venda: ");
	scanf("%f",&venda);
	if (venda>compra)
		printf("\n Teve Lucro. Valor de compra: %.2f , valor de venda: %.2f", compra,venda);
	else
		{
		if (venda<compra)
			printf("\n Teve prejuízo. Valor de compra: %.2f , valor de venda: %.2f", compra,venda);
		else
			printf("\n Os valores são iguais.");
		}
}
	
	
