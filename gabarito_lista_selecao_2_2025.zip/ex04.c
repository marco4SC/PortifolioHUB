/* 4. Construa o programa que calcule o peso ideal de uma pessoa.
Utilize as seguintes fórmulas:
- Se homem, o peso ideal é calculado assim: (72,7. altura) - 58;
- Se mulher, o peso ideal é calculado assim: (62,1. altura) - 44,7.
Analise o problema e verifique quais são os dados que o usuário precisa fornecer (digitar).
Teste 1: Entrada: altura = 1.70 e gênero = 1 Saída: peso ideal = 65.59 Kg
lista_selecao_2_2024 01/04/2024
Teste 2: Entrada: altura = 1.70 e gênero = 2 Saída: peso ideal = 60.8699999 Kg
ALTERAÇÕES:
a. Mostre o peso com duas casas decimais.
c. Troque a entrada para ‘m’ ou ‘f’.
Teste 3: altura = 1.8 genero = m Saída: peso ideal = 72.86 Kg
d. Mostre uma mensagem de erro se ele digitar valor de gênero diferente de ‘m’ ou ‘f’.
*/
#include <stdio.h>
#include <locale.h>

void main (void)
{
	setlocale(LC_ALL,"portuguese");
	float peso=0, altura=0,pesoideal=0;
	char gen;
	printf("\n Digite seu gênero 'f' para mulher ou 'h' para homem: ");
	scanf("%c",&gen);
	printf("\n Digite seu peso: ");
	scanf("%f",&peso);
	printf("\n Digite sua altura: ");
	scanf("%f",&altura);
	gen = gen & 0x4f;
	if (gen == 'F')
		{
		pesoideal = (62.1 * altura) - 44.7;
		printf("\n Seu peso ideal é %.2f .",pesoideal);
		}
	else
		if (gen == 'H')
			{
			pesoideal = (72.7 * altura) - 58.0;	
			printf("\n Seu peso ideal é %.2f .",pesoideal);
			}
		else
			printf("\n  Gênero inválido");
	
}
	
	
