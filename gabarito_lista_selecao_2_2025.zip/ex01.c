/* 1. Faça um programa que leia o ano de nascimento de uma pessoa e calcule sua idade. Após
isso verifique se ela já tem idade para votar (16 anos ou mais). mostre a mensagem informando
a situação dela:
a) A idade é xx anos e já pode votar.
b) A idade é xx anos e não pode votar.
ALTERAÇÕES:
a. Na tela de saída, mostre também a data de nascimento.
b. Mostre também a idade da pessoa.
*/
#include <stdio.h>
#include <locale.h>

void main (void)
{
	setlocale(LC_ALL,"portuguese");
	int anonasc=0, anoatual=0, dia=0, mes=0,idade=0;
	printf("\n Digite o ano atual: ");
	scanf("%d",&anoatual);
	printf("\n Digite o dia do seu nascimento: ");
	scanf("%d",&dia);
	printf("\n Digite o mês do seu nascimento: ");
	scanf("%d",&mes);
	printf("\n Digite o ano do seu nascimento: ");
	scanf("%d",&anonasc);
	idade = anoatual-anonasc;
	if (idade > 15)
		printf("\n Pode votar.");
	else
		printf("\n `Não pode votar.");
	printf("\n A sua idade é  %d anos e você nasceu em %d/%d/%d.",idade, dia,mes,anonasc);
	

}
	
	
