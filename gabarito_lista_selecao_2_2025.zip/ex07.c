/* 7. Refaça o programa que calcule a média aritmética de um aluno que realizou duas avaliações.
Além do valor da média, inclua na tela de saída uma das mensagens: “Aluno aprovado.”
ou “Aluno reprovado.”. Considere que o aluno será aprovado com a média maior ou igual a
cinco.
Teste 1: Entrada: nota1 = 5, nota2 = 6 Saída: Média = 5.5 Aluno aprovado.
Teste 2: Entrada: nota1 = 5, nota2 = 2 Saída: Média = 3.5 Aluno reprovado.
*/

#include <stdio.h>
#include <locale.h>

void main (void)
{
	setlocale(LC_ALL,"portuguese");
	float nota1=0,nota2=0, med=0,peso1=0,peso2=0;
	printf("\n Digite a nota 1: ");
	scanf("%f",&nota1);
	printf("\n Digite o peso da nota 1: ");
	scanf("%f",&peso1);
	printf("\n Digite a nota 2: ");
	scanf("%f",&nota2);
	printf("\n Digite o peso da nota 2: ");
	scanf("%f",&peso2);
	nota1 *=peso1;
	nota2 *=peso2;
	
	med = (nota1 + nota2)/8.0;
	printf("\n A média do aluno é %.2f", med);
	if(med>=5.0)
		printf(", Aluno Aprovado");
	else
		printf(", Aluno Reprovado");
	
}
	
		
	
