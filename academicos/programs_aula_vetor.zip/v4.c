 #include <stdio.h>
#include <locale.h>
void main(void)
    {                  
char v[]={'a','b','c'};
char v1[]="abc";
printf("\n %d   %d",sizeof(v), sizeof(v1));

}
