 #include <stdio.h>
#include <locale.h>
void main(void)
    {                  
int vet[40] = {0};
int i;
for(i=0;i<40;printf("\n %d",vet[i]),i++);
//for(i=0;i<40;i++)
//  printf("\n %d",vet[i]);
}
