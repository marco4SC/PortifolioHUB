 #include <stdio.h>
#include <locale.h>
#include <string.h>
void main(void)
{
int i,cont=0;
char vet[100]="ceub";
printf("\n Digite seu nome:" );
gets(vet);

for(i=0;vet[i]!='\0';i++)
{  if(vet[i]>=97) //testo se o elemento  � min�sculo
    {vet[i]-=32; // se for converte para mai�sculo
     cont++;
 	}
 }
printf("\n O vetor em maiusculas e %s\nforam convertidos %d  caracteres",vet,cont);
}

