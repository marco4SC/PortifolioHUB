#include <stdio.h>
#include <string.h>
#include <stdlib.h>
void main(void)
{
int i, c;
float notas_al[5][2];//5 linhas (cinco alunos) e 2 colunas (2 notas)
char aux[10];
for (i=0;i<5;i++)//loop de controle das linhas
	for (c=0;c<2;c++)//loop de controle das colunas
	{	printf ("\nDigite a nota %d do aluno %d: ",c+1,i+1);
	      notas_al[i][c]=atof(gets(aux));
	}
for (i=0;i<5;i++)
	{	printf ("\n A m�dia do aluno %d � %.2f", i+1,
(notas_al[i][0]+notas_al[i][1])/2.0);
	}
}
