/* 2. No programa anterior, n�s percorremos a matriz linha por linha, ou seja, 
fixamos o valor da linha e variamos a coluna. Agora vamos refaz�-lo percorrendo
 a matriz coluna por coluna, ou seja, fixamos o valor da coluna e variamos a linha.
  No final mostre os valores armazenados na matriz.
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
void main(void)
{
int l, c;
int num[3][4];//3 linhas e 4 colunas
char aux[10]; // utilizar na convers�o de char para int
for (c=0;c<4;c++)//loop de controle das colunas
	for (l=0;l<3;l++)//loop de controle das linhas

		{
			printf("\n Digite o valor da linha %d ,coluna %d: ",l+1,c+1);	
		    num[l][c]=atoi(gets(aux));
		}
	for (l=0;l<3;l++)//loop de controle das linhas
	for (c=0;c<4;c++)//loop de controle das colunas
			printf("\n O valor armazenado na linha %d  e coluna %d: %d",l+1,c+1,num[l][c]);
		

for (printf("\n"),l=0;l<3;printf("\n"),l++)//loop de controle das linhas
	for (c=0;c<4;c++)//loop de controle das colunas
			printf("%d ",num[l][c]);
		}
