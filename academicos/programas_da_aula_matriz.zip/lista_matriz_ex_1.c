/*1. Elabore um programa, utilizando la�os encadeados, para armazenar doze valores num�ricos
 inteiros numa matriz 3 x 4, ou seja, numa matriz com 3 linhas e 4 colunas. 
 No final mostre os valores armazenados na matriz.
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
void main(void)
{
int l, c;
int num[3][4];//3 linhas e 4 colunas
char aux[10]; // utilizar na convers�o de char para int
for (l=0;l<3;l++)//loop de controle das linhas
	for (c=0;c<4;c++)//loop de controle das colunas
		{
			printf("\n Digite o valor da linha %d ,coluna %d: ",l+1,c+1);	
		    num[l][c]=atoi(gets(aux));
		}
for (l=0;l<3;l++)//loop de controle das linhas
	for (c=0;c<4;c++)//loop de controle das colunas
			printf("\n O valor armazenado na linha %d  e coluna %d: %d",l+1,c+1,num[l][c]);
	
for (printf("\n"),l=0;l<3;printf("\n"),l++)//loop de controle das linhas
	for (c=0;c<4;c++)//loop de controle das colunas
			printf("%d ",num[l][c]);
}
