#include <stdio.h>
#include <string.h>
void main(void)
   {    int l,c;
   char op;
	char nomes_alunos[4][10];
	for(l=0;l<4;l++)//loop dos alunos
		{printf("\n digite o nome do aluno %d:",l +1);
		for(c=0;c<10;c++)//loop de controle do tamanho dos nomes
		    {	
				if(c<9)
					{
					op=getche();
					if (op==13)
						{nomes_alunos[l][c]='\0';
							break;
					}
					
					else
						nomes_alunos[l][c]=op;
					}
				else
					nomes_alunos[l][c]='\0';
	   		}}
	for(l=0;l<4;l++)
		 printf("\n O nome do aluno %d e %s",l+1,nomes_alunos[l] );
   }

