#include <stdio.h>
#include <string.h>
void main(void)
   {    int l,c;
	char nomes_anjos[4][10]={"Miguel", "Rafael", "Gabriel", "Querubim"};
	for(l=0;l<4;l++)
		 puts(nomes_anjos[l] );
   }
