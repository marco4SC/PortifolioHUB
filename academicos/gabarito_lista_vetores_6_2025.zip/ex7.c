/*
7. Dados dois vetores, “a” com dez elementos e “b“com vinte elementos, escreva um programa que faça a união destes dois vetores
 armazenando todos os elementos num terceiro vetor. Leia os dados dos vetores “a“e “b“ e no final mostre o vetor união.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>

void main() {
setlocale(LC_ALL, "portuguese");

    int i = 0, j=0, a[10] = {1,2,3,4,5,6,7,8,9,10}, b[20] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20}, c[30];

    //Leitura dos dados de A e alocação para C
    for (i = 0; i < 10; i++) {
        c[i] = a[i];
    }
   
    //Leitura dos dados de B e alocação para c
    for (i = 10, j=0; i < 30; i++,j++) {
        c[i] = b[j];
    }
    for (i = 0; i < 30; i++) 
    printf("\nPosição %d: %d", i, c[i]);


}
