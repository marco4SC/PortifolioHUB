/*
5. Elabore um programa que leia, some e imprima o resultado da soma posicional, 
entre dois vetores inteiros de 10 posições. Use um terceiro vetor para armazenar o resultado.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <stdlib.h>

void main() {
setlocale(LC_ALL, "portuguese");

    int i = 0, a[10] = {1,2,3,4,5,6,7,8,9,10}, b[10] = {1,2,3,4,5,6,7,8,9,10}, c[10]={0};
	char aux[10];
    //Leitura dos dados do vetor a
    for (i = 0; i < 10; i++) {
        printf("\n Digite o valor %d do vetor a: ",i+1);
		a[i]=atoi(gets(aux));
    }
   
    //Leitura dos dados do vetor b
    for (i = 0;i < 10; i++) {
        printf("\n Digite o valor %d do vetor b: ",i+1);
		b[i]=atoi(gets(aux));
    }
	printf("\nO resultado da adição dos vetores \"a\" e \"b\"  é\n");
	for (printf("\nElemento: "),i = 0; i < 10; i++) 
    printf("\t%d",i);
    for (printf("\nVetor a: "),i = 0; i < 10; i++) 
    printf("\t%d",a[i]);
	for (printf("\nVetor b: "),i = 0; i < 10; i++) 
    printf("\t%d",b[i]);
	for (printf("\nVetor c: "),i = 0; i < 10; i++) 
	{c[i]=a[i]+b[i];
    printf("\t%d",c[i]);
	}
}
