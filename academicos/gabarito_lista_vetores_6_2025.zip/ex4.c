/*
4. Refaça o programa anterior para mostrar também a quantidade de notas acima da média da turma
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <stdlib.h>

void main() {
setlocale(LC_ALL, "portuguese");

    int i = 0,cont=0;
	float nota[10]={0}, media=0;
	char aux[10];
    //Leitura das notas
    for (i = 0; i < 10; i++) {
        printf("\n Digite a nota do aluno %d: ",i+1);
		nota[i]=atof(gets(aux));
		media+=nota[i];
		if(nota>5.0)
			cont++;
    }
   system("cls"); //limpa a tela
	printf("\n              Relatório de Desempenho dos Alunos\n");
    //Leitura dos dados do vetor b
    for (i = 0;i < 10; i++) {
        printf("\n              O aluno %d tirou a nota %.2f",i+1,nota[i]);
		
    }
	printf("\nA média da turma é %.2f e %d alunos tiveram nota acima da média",media/10.0,cont);
	
}
