/*
6. Construa um programa que preencha um vetor de 100 elementos inteiros, colocando "1" na posição (= índice do vetor)
correspondente a um número par e "0" na posição (= índice do vetor) correspondente a um número ímpar.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>

void main() {
setlocale(LC_ALL, "portuguese");

    int i = 0,  vet[100] = {0};

    
    for (i = 0; i < 100; i++) 
        if(i%2 ==0)
				vet[i] = 1;
		else
				vet[i]=0;
    
    for (i = 0; i < 100; i++) 
    	printf("\n O valor do elemento %d é %d", i, vet[i]);
}
