/*
11. Elabore um programa para limitar a quantidade máxima de caracteres que poderemos digitar para
 uma entrada alfanumérica, ou seja, variável string. O usuário fornecerá uma palavra ou uma sentença
 que será finalizada quando ele digitar a tecla < enter > ou quando chegar ao limite máximo de sessenta
 caracteres digitados. No final mostre a quantidade de caracteres efetivamente digitados
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
void main() {
setlocale(LC_ALL, "portuguese");

    int i = 0,tam=0; 
	char vet[60];
	printf("\n Digite uma frase: ");
	for (i = 0; i <60; i++) {
		vet[i]=getche();
		if (vet[i]==0x0d)
		{	vet[i]=0;
			break;}
		if (i==59)
			vet[i]=0;
		
}
printf("\n A frase digitada foi %s ",vet);
}