/*
8. Selecione os elementos comuns aos dois vetores acima, armazenando-os num
 terceiro vetor. No final mostre os valores selecionados, ou seja, os elementos comuns.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>

void main() {
setlocale(LC_ALL, "portuguese");

    int i = 0, j=0, a[10] = {1,2,3,4,5,6,7,8,9,10};
	int c[20]={0};
	int  b[20] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
 
    for (i = 0; i < 10; i++) {
		for(j=0;j<20;j++)
			if(a[i]==b[j])
               c[i] = a[i];
    }
  	for (i = 0; i < 20; i++) 
    printf("\nPosição %d: %d", i, c[i]);
}
