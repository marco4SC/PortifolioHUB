/*
9. Elabore um programa que, dados dois vetores inteiros de 20 posições
, efetue as respectivas operações indicadas por um outro vetor de 20 posições de caracteres
 também fornecido pelo usuário, contendo as quatro operações aritméticas
 em qualquer combinação, armazenando os resultados num quarto vetor.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <stdlib.h>
void main() {
setlocale(LC_ALL, "portuguese");

    int i = 0, j=0, a[20] = {0}, b[20] = {0}, c[20]={0};
	char op[20],aux[10];
	
    for (i = 0; i < 20; i++) {
		printf("\nDigite o valor %d do vetor \"a\": ", i+1);
		a[i]=atoi(gets(aux));
		printf("\nDigite o valor %d do vetor \"b\": ", i+1);
		b[i]=atoi(gets(aux));
		printf("\nDigite a operação que será veita entre esses dois elementos \(+, - , /, *\): ");
		op[i]=getche();
}
  	for (i = 0; i < 20; i++) 
        {	
		switch(op[i])
		{
		case '+':
			c[i]=a[i]+b[i];
			break;
		case '-':
			c[i]=a[i]-b[i];
			break;
		case '*':
			c[i]=a[i]*b[i];
			break;
		case '/':
			c[i]=a[i]/b[i];
			break;
	}
}
	printf("\nO resultado da adição das operações com os vetores \"a\" e \"b\"  é\n");
	for (printf("\nElemento: "),i = 0; i < 20; i++) 
    printf("\t%d",i);
    for (printf("\nVetor a: "),i = 0; i < 20; i++) 
    printf("\t%d",a[i]);
	for (printf("\noperação: "),i = 0; i < 20; i++) 
    printf("\t%c",op[i]);
	for (printf("\nVetor b: "),i = 0; i < 20; i++) 
    printf("\t%d",b[i]);
	for (printf("\nVetor c: "),i = 0; i < 20; i++) 
	    printf("\t%d",c[i]);

}
