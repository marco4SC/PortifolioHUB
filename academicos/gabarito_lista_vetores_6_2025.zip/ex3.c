/*
3. Construa um programa que calcule a média aritmética de uma classe com dez alunos,
 onde cada aluno teve uma avaliação (use vetor). Gere um relatório, tela de saída,
 com o número e a nota dos alunos e no final mostre também a média da turma.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <stdlib.h>

void main() {
setlocale(LC_ALL, "portuguese");

    int i = 0;
	float nota[10]={0}, media=0;
	char aux[10];
    //Leitura das notas
    for (i = 0; i < 10; i++) {
        printf("\n Digite a nota do aluno %d: ",i+1);
		nota[i]=atof(gets(aux));
		media+=nota[i];
    }
   system("cls"); //limpa a tela
	printf("\n              Relatório de Desempenho dos Alunos\n");
    //Leitura dos dados do vetor b
    for (i = 0;i < 10; i++) {
        printf("\n              O aluno %d tirou a nota %.2f",i+1,nota[i]);
		
    }
	printf("\nA média da turma é %.2f",media/10.0);
	
}
