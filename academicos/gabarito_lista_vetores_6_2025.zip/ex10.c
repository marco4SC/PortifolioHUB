/*
10. Leia uma palavra e mostre-a na ordem inversa.
 Utilize a função comprimento da string.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <stdlib.h>
void main() {
setlocale(LC_ALL, "portuguese");

    int i = 0,tam=0; 
	char vet[20];
	printf("\n Digite uma frase: ");
	gets(vet);
	tam=strlen(vet);
	printf("\n A frase invertida é: ");
    for (i = tam; i >=0; i--) {
		printf("%c", vet[i]);
		
}
}