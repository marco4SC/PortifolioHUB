/*
2. Refaça o programa anterior, mostrando os valores 
armazenados no vetor na ordem inversa da entrada.
*/
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <stdlib.h>

void main() {
setlocale(LC_ALL, "portuguese");

    int i = 0, vet[4] = {0};
	char aux[10];
    //Leitura dos dados do vetor 
    for (i = 0; i < 4; i++) {
        printf("\n Digite o valor %d do vetor: ",i+1);
		vet[i]=atoi(gets(aux));
    }
    //mostrando os dados
    for (i = 3;i >= 0; i--) 
        printf("\n vet[%d] = %d",i,vet[i]);
	
}
