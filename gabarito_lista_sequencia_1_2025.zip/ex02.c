#include <stdio.h>
#include <locale.h>

void main (void)
{
	setlocale(LC_ALL,"portuguese");
	int n1, n2, soma, sub, mul;
	printf("\n Digite o primeiro valor: ");
	scanf("%d",&n1);
	printf("\n Digite o segundo valor: ");
	scanf("%d",&n2);
	soma = n1 + n2;
	printf("\n O resultado da soma de %d + %d = %d", n1 , n2, soma);
	sub = n1 - n2;
	printf("\n O resultado da subtra��o de %d - %d = %d", n1 , n2, sub);
	mul = n1 * n2;
	printf("\n O resultado da multiplica��o de de %d x %d = %d", n1 , n2, mul);
}
	
	
