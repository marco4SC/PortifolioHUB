#include <stdio.h>
#include <locale.h>

void main (void)
{
	setlocale(LC_ALL,"portuguese");
	float fah, tc;
	printf("\n Digite a temperatura em graus Fahrenheit: ");
	scanf("%f",&fah);
	tc = (fah -32)/1.8;
	printf("\n A temperatura %.2f�F em graus Celsius � %.2f�C", fah, tc);
	
}
	
	
