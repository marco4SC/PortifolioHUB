#include <stdio.h>
#include <locale.h>

void main (void)
{
	setlocale(LC_ALL,"portuguese");
	float pes, m;
	printf("\n Digite o valor em p�s: ");
	scanf("%f",&pes);
	m = pes * 0.3048;
	printf("\n O valor de %.2f p�s em metros � %.2f", pes,m);
	
}
	
	
