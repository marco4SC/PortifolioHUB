#include <stdio.h>
#include <locale.h>

void main (void)
{
	setlocale(LC_ALL,"portuguese");
	float nota1,nota2, med;
	printf("\n Digite a nota 1: ");
	scanf("%f",&nota1);
	printf("\n Digite a nota 2: ");
	scanf("%f",&nota2);
	med = (nota1 + nota2)/2.0;
	printf("\n A m�dia do aluno � %.2f", med);
	
}
	
	
