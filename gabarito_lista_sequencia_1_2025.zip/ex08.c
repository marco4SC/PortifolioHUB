#include <stdio.h>
#include <locale.h>
#define pi 3.141516
void main (void)
{
	setlocale(LC_ALL,"portuguese");
	float area, altura, raio;
	printf("\n Digite o raio do cilindro: ");
	scanf("%f",&raio);
	printf("\n Digite a altura do cilindro: ");
	scanf("%f",&altura);
	area = 2 * pi * raio * altura;
	printf("\n A �rea do cilindro de raio %.2f, altura %.2f � %.2f", raio, altura, area);
	
}
	
	
