#include <stdio.h>
#include <locale.h>
#define pi 3.141516
void main (void)
{
	setlocale(LC_ALL,"portuguese");
	float comp, raio;
	printf("\n Digite o raio do c�rculo: ");
	scanf("%f",&raio);
	comp = 2 * pi * raio;
	printf("\n O comprimento da circunfer�ncia de raio %.2f � %.2f", raio, comp);
	
}
	
	
