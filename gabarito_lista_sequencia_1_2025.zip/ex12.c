#include <stdio.h>
#include <locale.h>

void main (void)
{
	setlocale(LC_ALL,"portuguese");
	float n1, n2, soma, sub;
	printf("\n Digite o primeiro valor: ");
	scanf("%f",&n1);
	printf("\n Digite o segundo valor: ");
	scanf("%f",&n2);
	soma = n1 + n2;
	printf("\n O resultado da soma de %.2f + %.2f = %.2f", n1 , n2, soma);
	sub = n1 - n2;
	printf("\n O resultado da subtra��o de %.2f - %.2f = %.2f", n1 , n2, sub);

}
	
	
