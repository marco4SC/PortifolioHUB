#include <stdio.h>
#include <locale.h>

void main (void)
{
	setlocale(LC_ALL,"portuguese");
	float n1, n2, n3, med;
	printf("\n Digite o primeiro n�mero: ");
	scanf("%f",&n1);
	printf("\n Digite o segundo n�mero: ");
	scanf("%f",&n2);
	printf("\n Digite o terceiro n�mero: ");
	scanf("%f",&n3);
	med = (n1 + n2 +n3)/3.0;
	printf("\n A m�dia da soma de  %.2f, %.2f, %.2f, � %.2f", n1, n2, n3, med);
	
}
	
	
