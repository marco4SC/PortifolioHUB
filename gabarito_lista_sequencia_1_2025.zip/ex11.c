#include <stdio.h>
#include <locale.h>

void main (void)
{
	setlocale(LC_ALL,"portuguese");
	int n1, n2, aux;
	printf("\n Digite o primeiro valor: ");
	scanf("%d",&n1);
	printf("\n Digite o segundo valor: ");
	scanf("%d",&n2);
	aux = n1;
	n1 = n2;
	n2 = aux;
	printf("\n Os novos valores das vari�veis s�o:\n n1 = %d\n n2 = %d", n1 , n2);
	}
	
	
