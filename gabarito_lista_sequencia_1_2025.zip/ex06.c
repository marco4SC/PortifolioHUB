#include <stdio.h>
#include <locale.h>
#define pi 3.141516
void main (void)
{
	setlocale(LC_ALL,"portuguese");
	float area, raio;
	printf("\n Digite o raio do c�rculo: ");
	scanf("%f",&raio);
	area = pi * raio * raio;
	printf("\n A �rea do c�rculo de raio %.2f � %.2f", raio, area);
	
}
	
	
