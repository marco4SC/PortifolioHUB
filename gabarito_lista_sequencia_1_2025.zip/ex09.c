#include <stdio.h>
#include <locale.h>
#define pi 3.141516
void main (void)
{
	setlocale(LC_ALL,"portuguese");
	float vol, raio;
	printf("\n Digite o raio da esfera: ");
	scanf("%f",&raio);
	vol = (4.0/3.0) * pi * (raio * raio * raio);
	printf("\n O volume da esfera de raio %.2f � %.2f", raio, vol);
	
}
	
	
