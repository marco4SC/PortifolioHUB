#include <stdio.h>
#include <locale.h>

void main (void)
{
	setlocale(LC_ALL,"portuguese");
	float base, altura, area;
	printf("\n Digite o valor da base: ");
	scanf("%f",&base);
	printf("\n Digite o valor da altura: ");
	scanf("%f",&altura);
	area = (base * altura)/2.0;
	printf("\n A �rea do tri�ngulo de base %.3f, altura %.3f � %.3f", base, altura, area);
	
}
	
	
