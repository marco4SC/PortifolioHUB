#include <stdio.h>
#include <locale.h>

void main (void)
{
	setlocale(LC_ALL,"portuguese");
	float n1, n2, soma;
	printf("\n Digite o primeiro valor: ");
	scanf("%f",&n1);
	printf("\n Digite o segundo valor: ");
	scanf("%f",&n2);
	soma = n1 + n2;
	printf("\n O resultado da soma de %.2f + %.2f = %.2f", n1 , n2, soma);
	
	// outra solu��o seria n�o utilizar a vari�vel somo e colocar no printf
	// a opera��o de adi��o veja abaixo
	
	printf("\n O resultado da soma de %.2f + %.2f = %.2f", n1 , n2, n1 + n2);
}
	
	
