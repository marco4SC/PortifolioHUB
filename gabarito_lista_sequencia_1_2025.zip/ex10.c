#include <stdio.h>
#include <locale.h>
#define pi 3.141516
void main (void)
{
	setlocale(LC_ALL,"portuguese");
	float a, b , raiz;
	printf("\n Entre com o coeficiente \"a\" :");
	scanf("%f",&a);
	printf("\n Entre com o coeficiente \"b\" :");
	scanf("%f",&b);
	raiz = -b / a;;
	printf("\n A raiz da equa��o de 1� grau , com os coeficientes \"a\" = %.2f , \"b\" = %.2f � %.2f", a , b, raiz);
	
}
	
	
